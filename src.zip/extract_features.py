import features as F
from sequence import sequence

def getASAList(file, position, window=9):
    tmp_list = []
    while True:
        strTmp = file.readline()
        if strTmp == "":
            break

        tmp_list.append(strTmp)

    tmp_list = tmp_list[int(position) - 1 - window / 2 : int(position) - 1 + window / 2 + 1]
    tmp_list = [item.split("\t") for item in tmp_list]

    tmp_list = [item[1] for item in tmp_list]
    tmp_list = [item[1:len(item)-3] for item in tmp_list]

    return tmp_list

f = open("phosphoELM_all_2015-04.dump", "r")
filestr = f.readline()

result = []

stringResult = ""
pre_accID = ""

window = 9

f_out = open("features_output", "w")
while True:
    strTemp = f.readline()
    if strTemp == "":
        break

    strList = strTemp.split("\t")
    strList = strList[0:3]

    corpus = sequence(strList[1], strList[0], strList[2])

    f_out.write(str(F.feature_1_shannon_entropy(corpus)))
    f_out.write(',')
    f_out.write(str(F.feature_2_relative_entropy(corpus)))
    f_out.write(',')
    f_out.write(str(F.feature_3_information_gain(corpus)))
    f_out.write(',')

    ###### ASA ######
    f_ASA = open("./RVP_seq_output/" + strList[0] + ".out", "r")
    ASAList = getASAList(f_ASA, strList[2])
    f_out.write(",".join(str(x) for x in ASAList))

    f_out.write(str(F.feature_13_102_overlapping_properties(corpus)))
    f_out.write(',')

    f_out.write(",".join(str(x) for x in F.feature_103_106_hydrophobicity(corpus)))
    f_out.write(',')

    f_out.write(",".join(str(x) for x in F.feature_287_433_CTD(corpus)))
    f_out.write(',')

    f_out.write(",".join(str(x) for x in F.feature_434_493_socn(corpus)))
    f_out.write(',')

    f_out.write(",".join(str(x) for x in F.feature_494_593_quasi(corpus)))

    f_out.write('\n')
